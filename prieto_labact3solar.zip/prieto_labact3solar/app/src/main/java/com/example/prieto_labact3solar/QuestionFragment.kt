package com.example.prieto_labact3solar

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class QuestionFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_question, container, false)

        // Buttons
        val buttonLargest = view.findViewById<Button>(R.id.buttonLargestPlanet)
        val buttonMoons = view.findViewById<Button>(R.id.buttonMostMoons)
        val buttonSpins = view.findViewById<Button>(R.id.buttonSpinsSide)

        // Navigate with the selected question
        buttonLargest.setOnClickListener {
            val action = QuestionFragmentDirections.actionQuestionToAnswer(
                "What is the largest planet?", "Jupiter"
            )
            findNavController().navigate(action)
        }

        buttonMoons.setOnClickListener {
            val action = QuestionFragmentDirections.actionQuestionToAnswer(
                "Which planet has the most moons?", "Saturn"
            )
            findNavController().navigate(action)
        }

        buttonSpins.setOnClickListener {
            val action = QuestionFragmentDirections.actionQuestionToAnswer(
                "Which planet spins on its side?", "Uranus"
            )
            findNavController().navigate(action)
        }

        return view
    }
}
