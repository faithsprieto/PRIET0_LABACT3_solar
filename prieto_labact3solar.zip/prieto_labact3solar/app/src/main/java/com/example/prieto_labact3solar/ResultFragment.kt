package com.example.prieto_labact3solar

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class ResultFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_result, container, false)

        // Get arguments passed from QuestionFragment
        val args = ResultFragmentArgs.fromBundle(requireArguments())
        val resultText = view.findViewById<TextView>(R.id.resultText)

        // Display result
        resultText.text = if (args.isCorrect) {
            "Correct! ${args.explanation}"
        } else {
            "Wrong! ${args.explanation}"
        }

        return view
    }
}
