package com.example.prieto_labact3solar

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class AnswerFragment : Fragment() {

    private val planets = listOf("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_answer, container, false)

        // Get arguments passed from QuestionFragment
        val args = AnswerFragmentArgs.fromBundle(requireArguments())
        val questionText = view.findViewById<TextView>(R.id.answerQuestionText)
        val listView = view.findViewById<ListView>(R.id.answerPlanetsList)

        // Show the question text
        questionText.text = args.question

        // Populate the planet list
        listView.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, planets)

        // Handle user selection
        listView.setOnItemClickListener { _, _, position, _ ->
            val selected = planets[position]
            val isCorrect = selected == args.correctAnswer

            // Build explanation depending on the correct answer
            val explanation = when (args.correctAnswer) {
                "Jupiter" -> "Jupiter is the largest planet and is 2.5 times the mass of all the other planets put together."
                "Saturn" -> "Saturn has the most moons with 82 known moons."
                "Uranus" -> "Uranus spins on its side with its axis at nearly a right angle to the Sun."
                else -> ""
            }

            // Navigate to ResultFragment
            val action = AnswerFragmentDirections.actionAnswerToResult(isCorrect, explanation)
            findNavController().navigate(action)
        }

        return view
    }
}
